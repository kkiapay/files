# KKIAPAY

KkiaPay allows businesses to safely receive payments by mobile money, credit card and bank account.

Kkiapay is developer friendly solution that allows you to accept mobile money and credit card, and direct bank payments in your application or website. Before using this plugin, make sure you have a right Merchant Account on Kkiapay, otherwise go and create your account. It is free and without pain.

KKIAPAY is available in:

* Benin
* Senegal [WIP]
* [More details at ](https://kkiapay.me/features/supported-countries)

### Prerequisites

Prestashop greater than or equal 1.6 


## Usage

* Install and configure API public key on dashboard
* [More details at ](https://docs.kkiapay.me/v1/plugin-et-sdk/prestashop)
