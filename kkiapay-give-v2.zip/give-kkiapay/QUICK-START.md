# 🚀 Quick Start Guide - KKiapay for GiveWP v2.0.0

## Installation en 5 Minutes

### Étape 1 : Prérequis

- ✅ WordPress 5.0+
- ✅ GiveWP 3.0.0+ activé
- ✅ PHP 7.4+
- ✅ Compte KKiapay créé

### Étape 2 : Installer le plugin

```bash
# Option A : Copier le dossier
cp -r kkiapay-give /wp-content/plugins/

# Puis activer dans WordPress
# Extensions > KKiapay for GiveWP > Activer
```

### Étape 3 : Obtenir les clés API (5 min)

1. Aller sur https://app.kkiapay.me
2. Se connecter avec son compte
3. Aller dans **Développeurs > Clés API**
4. Copier :
   - **Public Key**
   - **Private Key**
   - **Secret Key**

> ⚠️ **Astuce** : Vous aurez 2 jeux de clés (Test et Production)

### Étape 4 : Configurer dans WordPress (5 min)

1. WordPress Admin → **Dons > Paramètres**
2. Cliquer sur **Passerelles de paiement**
3. Cliquer sur **KKiapay**
4. **Activer** la passerelle
5. Entrer les clés API
6. **Sauvegarder les paramètres**

### Étape 5 : Tester (5 min)

1. Activer le **Mode Test** dans GiveWP
2. Créer un formulaire de don test
3. Faire un don en sélectionnant **KKiapay**
4. Vérifier que le don s'enregistre

✅ **C'est fait !** Vous pouvez maintenant accepter des dons.

---

## Configuration du Webhook (Recommandé)

Le webhook permet la vérification automatique des paiements.

### Dans votre plugin (copier l'URL)

1. **Dons > Paramètres > Passerelles de paiement > KKiapay**
2. Chercher la section "**Webhook URL**"
3. **Copier l'URL** affichée

### Dans KKiapay Dashboard

1. Aller sur https://app.kkiapay.me/dashboard
2. **Développeurs > Webhooks**
3. **Ajouter** l'URL copiée
4. **Sauvegarder**

✅ Le webhook est maintenant actif !

---

## Personnaliser le Widget (Optionnel)

Dans **Dons > Paramètres > KKiapay**, vous pouvez :

### 1. Choisir les méthodes de paiement

```
- Tout (Mobile Money + Cartes)
- Mobile Money uniquement
- Cartes bancaires uniquement
```

### 2. Positionner le widget

```
- Centre de la page (recommandé)
- Côté gauche
- Côté droit
```

### 3. Changer la couleur

```
Entrer un code hex : #00A859
Ou laisser vide pour la couleur par défaut
```

---

## Passage en Production

Une fois les tests réussis :

### 1. Désactiver le Mode Test

**Dons > Paramètres > Général**

- Désactiver **Mode Test de Give**

### 2. Remplacer les clés

**Dons > Paramètres > Passerelles de paiement > KKiapay**

- Remplacer les clés de **test** par les clés de **production**
- Garder la même structure

### 3. Vérifier le webhook

- S'assurer que l'URL du webhook est toujours ajoutée dans KKiapay Dashboard
- (L'URL reste la même, mais avec les vraies clés)

### 4. Tester avec un petit montant

- Faire un don de test avec un vrai montant
- Vérifier que tout fonctionne

✅ Prêt pour la production !

---

## Dépannage Rapide

| Problème                     | Solution                                      |
| ---------------------------- | --------------------------------------------- |
| Plugin ne s'active pas       | Vérifier que GiveWP 3.0+ est activé           |
| Widget ne s'affiche pas      | Vérifier la clé publique, vider le cache      |
| Paiement ne s'enregistre pas | Vérifier toutes les clés API, activer webhook |
| Erreur de devise             | Vérifier que la devise est XOF dans GiveWP    |
| Erreur JavaScript            | F12 > Console, chercher les erreurs           |

---

## Fichiers Importants

| Fichier                             | Rôle                             |
| ----------------------------------- | -------------------------------- |
| `kkiapay-give.php`                  | Fichier principal du plugin      |
| `include/class-kkiapay-gateway.php` | Communication avec l'API KKiapay |
| `include/kkiapay-give-class.php`    | Logique GiveWP                   |
| `include/assets/js/kkiapay.js`      | Widget interaction               |

---

## Support et Documentation

- 📚 **Docs** : https://docs.kkiapay.me
- 💬 **Support** : https://support.kkiapay.me
- 📧 **Email** : support@kkiapay.me

---

## Prochaines Étapes

Après l'installation :

1. ✅ Créer des formulaires de don
2. ✅ Tester les paiements
3. ✅ Configurer le webhook
4. ✅ Passer en production
5. ✅ Promouvoir votre plateforme de don

---

## Questions Fréquentes

### Peut-on tester sans compte KKiapay ?

**Non**, vous devez un compte pour les clés API. Créez-en un gratuitement sur https://kkiapay.me

### Quel mode test utiliser ?

Utilisez les **clés de test** KKiapay ET le **Mode Test** de GiveWP

### Quelles devises sont supportées ?

Actuellement **XOF (CFA)** uniquement.

### Combien ça coûte ?

Les tarifs de KKiapay. Consultez https://kkiapay.me/pricing

### Puis-je accepter d'autres paiements aussi ?

Oui ! GiveWP supporte plusieurs passerelles en parallèle.

---

## Version

- **Version actuelle** : 2.0.0
- **Dernière mise à jour** : 13 janvier 2026
- **Compatibilité** : WordPress 5.0+, GiveWP 3.0.0+, PHP 7.4+

---

**🎉 Bon courage pour vos premières donations !**

_Besoin d'aide ? Contactez support@kkiapay.me_
