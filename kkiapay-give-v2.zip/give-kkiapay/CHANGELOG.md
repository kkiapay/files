# Changelog

Toutes les modifications notables de ce projet seront documentées dans ce fichier.

## [2.0.1] - 2026-03-10

### 🔧 Améliorations
- **Compatibilité WordPress 6.9+** : Mise à jour des tests et validation pour les dernières versions de WordPress.
- **Support GiveWP 4.14+** : Mise à jour de la compatibilité avec la version 4.x de GiveWP, incluant le support pour le nouveau système de Campagnes et le Visual Builder NextGen.

## [2.0.0] - 2026-01-13

### 🎉 Refonte Majeure - Compatible GiveWP 3.x

Cette version est une refonte complète du plugin pour assurer la compatibilité avec GiveWP 3.x et améliorer considérablement la fiabilité et la sécurité.

### ✨ Nouveautés

- **Support GiveWP 3.x** : Entièrement compatible avec GiveWP 3.0.0 et supérieur
- **Webhooks** : Ajout du support des webhooks pour la vérification automatique des paiements
- **API WordPress native** : Utilisation de `wp_remote_post()` au lieu de Guzzle pour plus de stabilité
- **Interface admin améliorée** : Paramètres réorganisés avec documentation intégrée
- **Gestion d'erreurs robuste** : Meilleure détection et signalement des erreurs de paiement
- **URL de webhook** : Affichage automatique de l'URL de webhook dans les paramètres

### 🔧 Améliorations

- **Code modernisé** : Refactorisation complète avec les meilleures pratiques WordPress
- **Sécurité renforcée** :
  - Validation des nonces améliorée
  - Vérification des signatures de webhook
  - Sanitization de toutes les entrées utilisateur
- **JavaScript amélioré** :
  - Meilleure gestion des erreurs
  - Support des événements de fermeture du widget
  - Gestion des échecs de paiement
  - Compatible avec les formulaires multi-étapes
- **Messages d'erreur** : Messages plus clairs en français et anglais
- **Logs** : Intégration avec le système de logs de GiveWP
- **Performance** : Chargement optimisé des scripts

### 🗑️ Suppressions

- **Dépendances Composer supprimées** :
  - kkiapay/kkiapay-php
  - guzzlehttp/guzzle
  - ralouphie/getallheaders
- **Fichier admin inutilisé** : Suppression de `include/admin/kkiapay-give-admin.php`
- **Code legacy** : Suppression du code obsolète pour GiveWP 2.x

### 🔄 Changements

- **Structure du plugin** :
  - Nouvelle classe `KkiapayGateway` pour la communication API
  - Refactorisation de `Kkiapay_Give` pour GiveWP 3.x
  - Namespace PHP ajouté pour éviter les conflits
- **Configuration** :
  - Les clés API sont maintenant des champs texte (plus de type password)
  - Nouveau champ pour l'URL de webhook
  - Options de personnalisation étendues
- **Vérification des paiements** :
  - Double vérification : immédiate + webhook
  - Meilleure gestion des montants partiels
  - Gestion des statuts PENDING, SUCCESS, FAILED

### 🐛 Corrections

- Correction du bug de compatibilité avec GiveWP 3.x
- Correction des erreurs de vérification de transaction
- Correction du chargement des scripts JavaScript
- Correction des traductions manquantes
- Correction du problème de soumission multiple du formulaire

### 📚 Documentation

- Nouveau fichier `README.md` complet
- Nouveau fichier `INSTALL.md` avec guide d'installation détaillé
- Nouveau fichier `CHANGELOG.md` (ce fichier)
- Commentaires de code améliorés (PHPDoc)

### ⚠️ Notes de migration

Si vous migrez depuis la version 1.0.0 :

1. **Sauvegardez votre base de données** avant la mise à jour
2. **Désactivez** l'ancienne version
3. **Supprimez** le dossier `vendor/` (n'est plus nécessaire)
4. **Installez** la nouvelle version
5. **Reconfigurez** vos clés API dans les paramètres
6. **Configurez** le webhook (recommandé)
7. **Testez** en mode test avant de passer en production

Les anciens dons seront conservés et restent accessibles.

### 🔐 Sécurité

Cette version corrige plusieurs problèmes de sécurité potentiels :

- Validation stricte des données entrantes
- Échappement correct des sorties
- Vérification des permissions
- Protection CSRF renforcée

### 📋 Exigences

- **WordPress** : 5.0 ou supérieur
- **PHP** : 7.4 ou supérieur (8.0+ recommandé)
- **GiveWP** : 3.0.0 ou supérieur
- **Compte KKiapay** : Requis

---

## [1.0.0] - Date initiale

### Première version

- Support de base pour GiveWP 2.5.2+
- Intégration du widget KKiapay
- Support Mobile Money et Cartes bancaires
- Configuration des clés API
- Options de personnalisation basiques
- Support de la devise XOF (CFA)
- Traductions FR/EN

### Limitations connues (corrigées en 2.0.0)

- Incompatibilité avec GiveWP 3.x
- Dépendance à Guzzle et bibliothèques externes
- Pas de support des webhooks
- Gestion d'erreurs limitée
- Code non structuré selon les standards WordPress

---

## Format

Ce changelog suit le format [Keep a Changelog](https://keepachangelog.com/fr/1.0.0/),
et ce projet adhère au [Semantic Versioning](https://semver.org/lang/fr/).

### Types de changements

- **Nouveautés** : Nouvelles fonctionnalités
- **Améliorations** : Améliorations de fonctionnalités existantes
- **Corrections** : Corrections de bugs
- **Suppressions** : Fonctionnalités supprimées
- **Changements** : Modifications de fonctionnalités existantes
- **Sécurité** : Corrections de vulnérabilités
- **Documentation** : Mises à jour de la documentation
