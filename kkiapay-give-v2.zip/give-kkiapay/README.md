# KKiapay for GiveWP

Accept donations via Mobile Money (MTN, Moov, Orange, Wave, FreeMoney) and credit cards through KKiapay payment gateway.

## Description

KKiapay for GiveWP enables your non-profit organization to receive donations through various African mobile money services and international credit cards. The plugin seamlessly integrates with GiveWP to provide a secure and user-friendly payment experience.

## Supported Payment Methods

- **Mobile Money**: MTN Mobile Money, Moov Money, Orange Money, Wave, FreeMoney
- **Credit Cards**: Visa, Mastercard

## Features

- ✅ Compatible with GiveWP 3.x
- ✅ Support for test and live modes
- ✅ Secure payment processing via KKiapay API
- ✅ Webhook support for automatic payment verification
- ✅ Customizable payment widget (position, theme, payment methods)
- ✅ Multiple currency support (XOF/CFA)
- ✅ Multilingual ready (English and French translations included)
- ✅ No external dependencies (uses WordPress HTTP API)

## Requirements

- WordPress 5.0 or higher (Tested up to 6.9)
- PHP 7.4 or higher
- GiveWP 3.0.0 or higher (Tested up to 4.14.2)
- A KKiapay account ([Sign up here](https://kkiapay.me))

## Installation

1. Upload the plugin files to `/wp-content/plugins/kkiapay-give/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **Donations > Settings > Payment Gateways > KKiapay**
4. Enter your KKiapay API keys (get them from [KKiapay Dashboard](https://app.kkiapay.me))
5. Enable the gateway and save settings
6. (Optional) Configure webhook URL in your KKiapay dashboard for automatic payment verification

See [INSTALL.md](INSTALL.md) for detailed installation instructions.

## Configuration

### API Keys

1. Log in to your [KKiapay Dashboard](https://app.kkiapay.me)
2. Navigate to **Developers > API Keys**
3. Copy your Public, Private, and Secret keys
4. Paste them in the plugin settings

**Important**: Use test mode keys during development and switch to live keys for production.

### Webhook Setup (Recommended)

To enable automatic payment verification:

1. Copy the webhook URL from the plugin settings page
2. Go to [KKiapay Dashboard > Developers > Webhooks](https://app.kkiapay.me/dashboard/developers/keys)
3. Add the webhook URL
4. This ensures payments are verified even if the user closes their browser

## Usage

1. Create or edit a donation form in GiveWP
2. Donors will see KKiapay as a payment option during checkout
3. When selected, the KKiapay payment widget will open
4. Donors can choose their preferred payment method
5. After successful payment, the donation is recorded automatically

## Frequently Asked Questions

### Which currencies are supported?

Currently, the plugin supports XOF (CFA Franc). If you need support for additional currencies, please contact KKiapay support.

### Can I test before going live?

Yes! Enable Test Mode in GiveWP settings and use your test API keys from KKiapay dashboard.

### What happens if payment verification fails?

The plugin uses multiple verification methods:

- Immediate verification after payment
- Webhook verification (if configured)
- Manual verification available in donation details

### Where can I get support?

- Documentation: [https://docs.kkiapay.me](https://docs.kkiapay.me)
- Support: [https://support.kkiapay.me](https://support.kkiapay.me)
- Email: support@kkiapay.me

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a detailed list of changes.

### Latest Version: 2.0.1 (2026-03-10)

- Added compatibility for WordPress 6.9+
- Added compatibility for GiveWP 4.14+ (Campaigns & NextGen Visual Builder)
- Removed dependency on Guzzle (now uses WordPress HTTP API)
- Added webhook support for automatic payment verification
- Improved error handling and payment verification
- Enhanced admin interface with better documentation
- Added support for multiple payment methods selection
- Improved JavaScript with better error handling
- Updated translations
- Security improvements

## Credits

Developed with ❤️ by the [KKiapay Developer Team](https://kkiapay.me)

## License

This plugin is licensed under the GPL v2 or later.
