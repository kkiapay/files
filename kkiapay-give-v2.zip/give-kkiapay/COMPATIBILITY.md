# Compatibilité - KKiapay Give Plugin

## Versions Supportées

### WordPress

- **Minimum requise** : 5.0+
- **Testé jusqu'à** : 6.4+
- **PHP minimum** : 7.4+

### GiveWP

- **Minimum requise** : 2.5.0+
- **Testé jusqu'à** : 3.5.0+

## Compatibilité Rétroactive

Le plugin est conçu pour fonctionner avec **GiveWP 2.5.0 et supérieur**, y compris la série 3.x.

### Fonctionnalités par Version

#### GiveWP 2.5.x - 2.x.x

- ✅ Enregistrement des passerelles de paiement
- ✅ Traitement des paiements
- ✅ Paramètres administrateur
- ✅ Support des devises personnalisées
- ✅ Scripts et styles frontaux
- ⚠️ Webhooks (fonctionnalité de base)

#### GiveWP 3.0.0 - 3.x.x

- ✅ Enregistrement des passerelles de paiement
- ✅ Traitement des paiements
- ✅ Paramètres administrateur
- ✅ Support des devises personnalisées
- ✅ Scripts et styles frontaux
- ✅ Webhooks complets

## Stratégie de Compatibilité

Le plugin utilise une approche défensive avec vérifications d'existence de fonctions :

```php
// Exemple : Vérification avant utilisation
if (function_exists('give_get_option')) {
    $value = give_get_option('setting_key');
} else {
    $value = get_option('give_setting_key');
}
```

### Fonctions avec Fallback

- `give_get_option()` → `get_option('give_' . option)`
- `give_set_error()` → Stockage direct en session
- `give_is_test_mode()` → Vérification directe de l'option

### Hooks Compatibles

Les hooks utilisés fonctionnent sur toutes les versions :

- `give_payment_gateways` (2.5.0+)
- `give_gateway_kkiapay` (2.5.0+)
- `give_currencies` (2.5.0+)
- `give_get_sections_gateways` (2.5.0+)
- `give_get_settings_gateways` (2.5.0+)

## Dépendances

### Requises

- WordPress 5.0+
- GiveWP 2.5.0+
- PHP 7.4+

### Optionnelles

- Composer (pour le développement)
- Git (pour le versioning)

## Tests de Compatibilité

### Environnements Testés

```
✅ WordPress 5.0 + GiveWP 2.5.0
✅ WordPress 5.5 + GiveWP 2.10.0
✅ WordPress 6.0 + GiveWP 3.0.0
✅ WordPress 6.2 + GiveWP 3.3.0
✅ WordPress 6.4 + GiveWP 3.5.0
```

## Notes de Migration

### De GiveWP 2.x à 3.x

Le plugin gère automatiquement les différences :

- Structure de paramètres mise à jour
- Nouvelles fonctions API disponibles
- Rétrocompatibilité maintenue

### Installation

1. Assurez-vous que WordPress 5.0+ et GiveWP 2.5.0+ sont installés
2. Téléchargez et activez le plugin
3. Le plugin accepte automatiquement votre version de GiveWP

## Support et Signalement de Bugs

Si vous rencontrez des problèmes de compatibilité :

1. Vérifiez que vous avez les versions minimales requises
2. Consultez les logs WordPress (`wp-content/debug.log`)
3. Contactez le support : support@kkiapay.me

## Historique des Versions

### v2.0.0 (2026-01-13)

- ✅ Compatible GiveWP 2.5.0+
- ✅ Compatible GiveWP 3.0.0+
- ✅ Support retour en arrière
- ✅ Vérifications de compatibilité automatiques
