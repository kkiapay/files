# Installation et Configuration - KKiapay for GiveWP

## Instructions d'installation

### 1. Préparation

Avant d'installer le plugin, assurez-vous d'avoir :

- WordPress 5.0 ou supérieur
- PHP 7.4 ou supérieur
- GiveWP 3.0.0 ou supérieur installé et activé
- Un compte KKiapay (créez-en un sur [kkiapay.me](https://kkiapay.me))

### 2. Installation du plugin

#### Option A : Installation manuelle

1. Téléchargez le dossier du plugin
2. Uploadez le dossier complet dans `/wp-content/plugins/`
3. Activez le plugin depuis le menu "Extensions" de WordPress

#### Option B : Via l'admin WordPress

1. Compressez le dossier en fichier .zip
2. Dans WordPress, allez dans Extensions > Ajouter
3. Cliquez sur "Téléverser une extension"
4. Choisissez le fichier .zip et cliquez sur "Installer"
5. Activez le plugin

### 3. Configuration de base

#### Étape 1 : Récupérer vos clés API KKiapay

1. Connectez-vous à votre [Dashboard KKiapay](https://app.kkiapay.me)
2. Allez dans **Développeurs > Clés API**
3. Vous verrez deux jeux de clés :
   - **Clés de Test** : Pour tester le plugin
   - **Clés de Production** : Pour les vrais paiements

Pour chaque jeu, notez :

- Clé Publique (Public Key)
- Clé Privée (Private Key)
- Clé Secrète (Secret Key)

#### Étape 2 : Configurer le plugin

1. Dans WordPress, allez dans **Dons > Paramètres**
2. Cliquez sur l'onglet **Passerelles de paiement**
3. Cliquez sur **KKiapay**
4. Activez la passerelle KKiapay
5. Entrez vos clés API :
   - Si GiveWP est en **Mode Test** : utilisez vos clés de test
   - Si GiveWP est en **Mode Production** : utilisez vos clés de production

#### Étape 3 : Personnaliser les options (optionnel)

Dans les paramètres KKiapay, vous pouvez configurer :

- **Méthodes de paiement** :

  - Tout (Mobile Money + Cartes bancaires)
  - Mobile Money uniquement
  - Cartes bancaires uniquement

- **Position du widget** :

  - Centre de la page (recommandé)
  - Côté gauche
  - Côté droit

- **Couleur du thème** :
  - Laissez vide pour la couleur par défaut
  - Entrez un code couleur hexadécimal (ex: #00A859)

### 4. Configuration du Webhook (Recommandé)

Le webhook permet de vérifier automatiquement les paiements, même si l'utilisateur ferme son navigateur.

1. Dans les paramètres KKiapay du plugin, copiez l'URL du webhook affichée
2. Allez sur votre [Dashboard KKiapay](https://app.kkiapay.me)
3. Naviguez vers **Développeurs > Webhooks**
4. Ajoutez l'URL copiée comme webhook
5. Sauvegardez

### 5. Test du plugin

#### Mode Test

1. Activez le **Mode Test** dans GiveWP (Dons > Paramètres > Général)
2. Assurez-vous d'utiliser vos **clés de test** KKiapay
3. Créez un formulaire de don test
4. Faites un don test en sélectionnant KKiapay comme méthode de paiement
5. Utilisez les numéros de test fournis par KKiapay :
   - Pour Mobile Money : utilisez un numéro de test depuis votre dashboard
   - Pour Carte bancaire : utilisez les coordonnées de test

#### Passage en Production

Une fois les tests réussis :

1. Désactivez le **Mode Test** dans GiveWP
2. Remplacez les clés de test par vos **clés de production** KKiapay
3. Vérifiez que le webhook est configuré
4. Testez avec un petit montant réel
5. Le plugin est prêt à recevoir des dons !

## Dépannage

### Le plugin ne s'active pas

- Vérifiez que GiveWP 3.0+ est installé et activé
- Vérifiez la version de PHP (minimum 7.4)
- Vérifiez les logs d'erreur WordPress

### Le widget KKiapay ne s'affiche pas

- Vérifiez que vous avez bien entré la clé publique
- Vérifiez que la clé correspond au mode (Test/Production)
- Ouvrez la console du navigateur pour voir les erreurs JavaScript
- Videz le cache de votre navigateur

### Le paiement n'est pas enregistré

- Vérifiez que toutes les clés API sont correctes
- Vérifiez que le webhook est bien configuré
- Consultez les logs dans Dons > Outils > Logs
- Contactez le support KKiapay si le problème persiste

### Erreur "Currency not supported"

- Le plugin supporte uniquement XOF (CFA)
- Changez la devise dans GiveWP : Dons > Paramètres > Général > Devise

## Migration depuis l'ancienne version

Si vous utilisez déjà une ancienne version du plugin :

1. **Sauvegardez votre base de données** avant la mise à jour
2. Désactivez l'ancienne version
3. Installez la nouvelle version (2.0.0)
4. Activez le plugin
5. Reconfigurez vos clés API dans les nouveaux paramètres
6. Testez en mode test avant de passer en production

**Note** : La nouvelle version n'utilise plus Guzzle et les dépendances Composer. Les anciens dons restent intacts.

## Support

Si vous rencontrez des problèmes :

- Documentation : [https://docs.kkiapay.me](https://docs.kkiapay.me)
- Support : [https://support.kkiapay.me](https://support.kkiapay.me)
- Email : support@kkiapay.me
- GitHub : Ouvrez une issue sur le repository

## Fonctionnalités avancées

### Personnalisation du widget

Le widget KKiapay peut être personnalisé via les options :

- Position sur la page
- Couleur du thème (correspond à votre charte graphique)
- Méthodes de paiement acceptées

### Logs et débogage

Pour activer les logs détaillés :

1. Allez dans Dons > Paramètres > Avancé
2. Activez les logs GiveWP
3. Les erreurs de paiement seront enregistrées dans Dons > Outils > Logs

### Webhooks

Le webhook permet :

- Vérification asynchrone des paiements
- Mise à jour automatique du statut des dons
- Fiabilité accrue même si le donateur ferme la page

URL du webhook : `https://votresite.com/?kkiapay-give-webhook=1`

## Sécurité

Le plugin :

- Utilise uniquement l'API WordPress native
- Valide tous les paiements côté serveur
- Vérifie les signatures des webhooks
- Ne stocke jamais les informations de carte bancaire
- Respecte les standards de sécurité PCI-DSS via KKiapay
