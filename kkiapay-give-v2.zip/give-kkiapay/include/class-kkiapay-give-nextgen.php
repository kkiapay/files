<?php
namespace KkiapayGive;

use Give\Donations\Models\Donation;
use Give\Framework\PaymentGateways\PaymentGateway;
use Give\Framework\PaymentGateways\Commands\GatewayCommand;
use Give\Framework\PaymentGateways\Commands\PaymentComplete;
use Give\Framework\PaymentGateways\Commands\PaymentRefunded;
use Give\Framework\PaymentGateways\Exceptions\PaymentGatewayException;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class KkiapayGiveNextGen extends PaymentGateway {

    public static function id(): string {
        return 'kkiapay';
    }

    public function getId(): string {
        return self::id();
    }

    public function getName(): string {
        return __( 'KKiapay', 'kkiapay-give' );
    }

    public function getPaymentMethodLabel(): string {
        return __( 'kkiapay', 'kkiapay-give' );
    }

    /**
     * Required by NextGenPaymentGatewayInterface.
     * Returns the URL of the JS file that registers this gateway
     * with window.givewp.gateways.register().
     */
    public function enqueueScript( int $formId ): void {
        wp_enqueue_script(
            'kkiapay-widget',
            'https://cdn.kkiapay.me/k.js',
            [],
            KKIAPAY_GIVE_VERSION,
            true
        );

        wp_enqueue_script(
            'give-kkiapay-nextgen',
            KKIAPAY_GIVE_PLUGIN_URL . 'include/assets/js/kkiapay-nextgen.js',
            [ 'kkiapay-widget', 'wp-element' ],
            KKIAPAY_GIVE_VERSION,
            true
        );

        wp_localize_script( 'give-kkiapay-nextgen', 'give_kkiapay_nextgen_vars', array(
            'key'           => give_get_option( 'public_key_kkiapay', '' ),
            'sandbox'       => give_is_test_mode() ? 'true' : 'false',
            'position'      => give_get_option( 'position_kkiapay', 'center' ),
            'theme'         => give_get_option( 'theme_kkiapay', '' ),
            'paymentmethod' => give_get_option( 'payment_method_kkiapay', 'all' ),
        ) );
    }

    /**
     * Required by NextGenPaymentGatewayInterface.
     * Must return the URL of the enqueued JS script so GiveWP can
     * register it in the Visual Form Builder gateway list.
     */
    public function getJsHandleString(): string {
        return 'give-kkiapay-nextgen';
    }

    /**
     * Legacy form field markup (Option-based forms / GiveWP < 3 back-compat).
     */
    public function getLegacyFormFieldMarkup( int $formId, array $args ): string {
        return '';
    }

    public function createPayment( Donation $donation, $gatewayData ): GatewayCommand {
        $transactionId = isset( $gatewayData['kkiapay_transaction_id'] )
            ? $gatewayData['kkiapay_transaction_id']
            : null;

        if ( ! $transactionId ) {
            throw new PaymentGatewayException(
                __( 'Missing transaction ID.', 'kkiapay-give' )
            );
        }

        $kkiapay = new KkiapayGateway(
            give_get_option( 'public_key_kkiapay' ),
            give_get_option( 'private_key_kkiapay' ),
            give_get_option( 'secret_key_kkiapay' ),
            give_is_test_mode()
        );

        $response = $kkiapay->verifyTransaction( $transactionId );

        if ( ! isset( $response->status ) || $response->status !== 'SUCCESS' ) {
            throw new PaymentGatewayException(
                __( 'Payment verification failed.', 'kkiapay-give' )
            );
        }

        return new PaymentComplete( $transactionId );
    }

    public function refundPayment( Donation $donation ): GatewayCommand {
        $transactionId = $donation->gatewayTransactionId;

        if ( ! $transactionId ) {
            throw new PaymentGatewayException(
                __( 'No transaction ID found for refund.', 'kkiapay-give' )
            );
        }

        $kkiapay = new KkiapayGateway(
            give_get_option( 'public_key_kkiapay' ),
            give_get_option( 'private_key_kkiapay' ),
            give_get_option( 'secret_key_kkiapay' ),
            give_is_test_mode()
        );

        $response = $kkiapay->refundTransaction( $transactionId );

        if ( is_wp_error( $response ) ) {
            throw new PaymentGatewayException( $response->get_error_message() );
        }

        return new PaymentRefunded();
    }
}
