<?php
/**
 * KKiapay Gateway Class
 * 
 * Handles API communication with KKiapay service
 * Similar to WooCommerce plugin but adapted for GiveWP
 */

namespace KkiapayGive;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Constants
 */
final class Constants {
    const BASE_URL = "https://api.kkiapay.me";
    const SANDBOX_URL = "https://api-sandbox.kkiapay.me";
}

/**
 * Transaction Status Constants
 */
final class STATUS {
    const SUCCESS = "SUCCESS";
    const INVALID_TRANSACTION = "INVALID_TRANSACTION";
    const INVALID_TRANSACTION_TYPE = "INVALID_TRANSACTION_TYPE";
    const TRANSACTION_NOT_FOUND = "TRANSACTION_NOT_FOUND";
    const TRANSACTION_NOT_ELIGIBLE = "TRANSACTION_NOT_ELIGIBLE";
    const INSUFFICIENT_FUND = "INSUFFICIENT_FUND";
    const PENDING = "PENDING";
    const FAILED = "FAILED";
    const REVERTED = "REVERTED";
}

/**
 * KKiapay Gateway Class
 */
class KkiapayGateway {
    
    /**
     * Public API key
     * @var string
     */
    private $public_key;
    
    /**
     * Private API key
     * @var string
     */
    private $private_key;
    
    /**
     * Secret key
     * @var string
     */
    private $secret;
    
    /**
     * Sandbox mode
     * @var bool
     */
    private $sandbox;
    
    /**
     * Constructor
     * 
     * @param string $public_key Public API key
     * @param string $private_key Private API key
     * @param string|null $secret Secret key
     * @param bool $sandbox Sandbox mode
     */
    public function __construct($public_key, $private_key, $secret = null, $sandbox = false) {
        $this->public_key = $public_key;
        $this->private_key = $private_key;
        $this->secret = $secret;
        $this->sandbox = $sandbox;
    }
    
    /**
     * Verify a transaction
     * 
     * @param string $transactionId Transaction ID to verify
     * @return object Transaction data
     */
    public function verifyTransaction($transactionId) {
        $base_url = $this->sandbox ? Constants::SANDBOX_URL : Constants::BASE_URL;
        
        $response = wp_remote_post($base_url . '/api/v1/transactions/status', array(
            'timeout' => 30,
            'body' => array('transactionId' => $transactionId),
            'headers' => array(
                'Accept' => 'application/json',
                'Content-Type' => 'application/x-www-form-urlencoded',
                'X-API-KEY' => $this->public_key,
                'X-PRIVATE-KEY' => $this->private_key,
                'X-SECRET-KEY' => $this->secret
            )
        ));
        
        if (is_wp_error($response)) {
            give_record_gateway_error(
                __('KKiapay Gateway Error', 'kkiapay-give'),
                sprintf(__('Error verifying transaction: %s', 'kkiapay-give'), $response->get_error_message())
            );
            
            return (object) array(
                'status' => STATUS::TRANSACTION_NOT_FOUND,
                'message' => $response->get_error_message()
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        
        if (200 !== $response_code) {
            give_record_gateway_error(
                __('KKiapay Gateway Error', 'kkiapay-give'),
                sprintf(__('HTTP Error %d: %s', 'kkiapay-give'), $response_code, wp_remote_retrieve_body($response))
            );
            
            return (object) array(
                'status' => STATUS::TRANSACTION_NOT_FOUND,
                'message' => sprintf(__('HTTP Error: %d', 'kkiapay-give'), $response_code)
            );
        }
        
        $response_body = wp_remote_retrieve_body($response);
        return json_decode($response_body);
    }
    
    /**
     * Refund a transaction
     * 
     * @param string $transactionId Transaction ID to refund
     * @return object|WP_Error Refund response
     */
    public function refundTransaction($transactionId) {
        $base_url = $this->sandbox ? Constants::SANDBOX_URL : Constants::BASE_URL;
        
        $response = wp_remote_post($base_url . '/api/v1/transactions/revert', array(
            'timeout' => 30,
            'body' => array('transactionId' => $transactionId),
            'headers' => array(
                'Accept' => 'application/json',
                'Content-Type' => 'application/x-www-form-urlencoded',
                'X-API-KEY' => $this->public_key
            )
        ));
        
        if (is_wp_error($response)) {
            return new \WP_Error('kkiapay_refund_error', $response->get_error_message());
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        
        if (200 !== $response_code) {
            $error_body = json_decode(wp_remote_retrieve_body($response));
            $error_message = isset($error_body->message) 
                ? $error_body->message 
                : __('Unable to process refund at the moment. Try again later.', 'kkiapay-give');
            
            return new \WP_Error('kkiapay_refund_error', $error_message);
        }
        
        return json_decode(wp_remote_retrieve_body($response));
    }
    
    /**
     * Get API base URL
     * 
     * @return string Base URL
     */
    public function getBaseUrl() {
        return $this->sandbox ? Constants::SANDBOX_URL : Constants::BASE_URL;
    }
    
    /**
     * Check if sandbox mode is enabled
     * 
     * @return bool
     */
    public function isSandbox() {
        return $this->sandbox;
    }
}
