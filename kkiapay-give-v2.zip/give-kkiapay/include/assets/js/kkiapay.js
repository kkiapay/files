/**
 * KKiapay for GiveWP - Payment Widget Integration
 * Version: 2.0.0
 */

(function () {
  "use strict";

  /**
   * Initialize KKiapay payment widget
   */
  function initKkiapayWidget() {
    let submitWithSuccess = false;
    const formWraps = document.querySelectorAll(".give-form-wrap");

    if (!formWraps.length) {
      return;
    }

    Array.prototype.forEach.call(formWraps, function (formWrap) {
      const formElement = formWrap.querySelector(".give-form");

      if (!formElement) {
        return;
      }

      // Store original submit handler
      const originalOnSubmit = formElement.onsubmit;

      // Override form submit
      formElement.onsubmit = function (evt) {
        const selectedGateway = formElement.querySelector(
          ".give-gateway:checked"
        );

        if (!selectedGateway) {
          if (originalOnSubmit) {
            return originalOnSubmit.call(this, evt);
          }
          return;
        }

        const gatewayValue = selectedGateway.value;

        // Handle KKiapay payment
        if ("kkiapay" === gatewayValue && !submitWithSuccess) {
          evt.stopImmediatePropagation();
          evt.preventDefault();

          processKkiapayPayment(formElement);
          return false;
        } else if (originalOnSubmit) {
          return originalOnSubmit.call(this, evt);
        }
      };

      // Load KKiapay widget script
      loadKkiapayScript(formElement);
    });

    /**
     * Process KKiapay payment
     *
     * @param {HTMLElement} formElement Form element
     */
    function processKkiapayPayment(formElement) {
      // Get donation amount
      const amountElement = formElement.querySelector(
        ".give-final-total-amount"
      );
      if (!amountElement) {
        console.error("KKiapay: Amount element not found");
        return;
      }

      const amount = parseFloat(amountElement.getAttribute("data-total"));

      // Get donor information
      const firstNameInput = formElement.querySelector(
        'input[name="give_first"]'
      );
      const lastNameInput = formElement.querySelector(
        'input[name="give_last"]'
      );
      const emailInput = formElement.querySelector('input[name="give_email"]');

      if (!firstNameInput || !lastNameInput || !emailInput) {
        console.error("KKiapay: Required donor information fields not found");
        return;
      }

      const firstName = firstNameInput.value;
      const lastName = lastNameInput.value;
      const email = emailInput.value;

      // Get KKiapay configuration
      const config = window.give_kkiapay_vars || {};

      // Prepare KKiapay widget options
      const kkiapayOptions = {
        amount: parseInt(amount),
        name: firstName + " " + lastName,
        email: email,
        key: config.key,
        sandbox: config.sandbox === "true",
        theme: config.theme || "",
        position: config.position || "center",
        paymentmethod: [config.paymentmethod || "all"],
        reason: "Donation",
        sdk: "givewp",
        data: {
          sdk: "givewp",
          donor_name: firstName + " " + lastName,
          donor_email: email,
        },
      };

      // Open KKiapay widget
      if (typeof window.openKkiapayWidget === "function") {
        window.openKkiapayWidget(kkiapayOptions);
      } else {
        console.error("KKiapay: Widget function not available");
        alert("Payment system is not ready. Please try again.");
        resetDonateButton(formElement);
      }
    }

    /**
     * Load KKiapay widget script
     *
     * @param {HTMLElement} formElement Form element
     */
    function loadKkiapayScript(formElement) {
      // Check if script already loaded
      if (window.openKkiapayWidget) {
        setupKkiapayListeners(formElement);
        return;
      }

      const script = document.createElement("script");
      script.onload = function () {
        setupKkiapayListeners(formElement);
      };
      script.onerror = function () {
        console.error("KKiapay: Failed to load payment widget script");
      };
      script.src = "https://cdn.kkiapay.me/k.js";
      document.head.appendChild(script);
    }

    /**
     * Setup KKiapay event listeners
     *
     * @param {HTMLElement} formElement Form element
     */
    function setupKkiapayListeners(formElement) {
      if (!window.addSuccessListener) {
        return;
      }

      // Success listener
      window.addSuccessListener(function (response) {
        if (!response || !response.transactionId) {
          console.error("KKiapay: Invalid transaction response");
          resetDonateButton(formElement);
          return;
        }

        // Add transaction ID to form
        let transactionInput = formElement.querySelector(
          'input[name="give_kkiapay_transaction_id"]'
        );

        if (!transactionInput) {
          transactionInput = document.createElement("input");
          transactionInput.setAttribute("type", "hidden");
          transactionInput.setAttribute("name", "give_kkiapay_transaction_id");
          formElement.appendChild(transactionInput);
        }

        transactionInput.setAttribute("value", response.transactionId);

        // Submit form
        submitWithSuccess = true;
        formElement.submit();
      });

      // Handle widget close
      window.addEventListener("message", function (e) {
        if (e.data === "close" || e.data === "KPAY_CLOSE") {
          resetDonateButton(formElement);
        }
      });

      // Failed payment listener
      if (window.addFailedListener) {
        window.addFailedListener(function (error) {
          console.error("KKiapay: Payment failed", error);
          resetDonateButton(formElement);

          // Show error message
          showErrorMessage(formElement, "Payment failed. Please try again.");
        });
      }
    }

    /**
     * Reset donate button to original state
     *
     * @param {HTMLElement} formElement Form element
     */
    function resetDonateButton(formElement) {
      const buttonWrap = formElement.querySelector(".give-submit-button-wrap");
      if (!buttonWrap) {
        return;
      }

      const donateButton = buttonWrap.querySelector(
        "#give-purchase-button, .give-submit"
      );
      const loadingAnimation = buttonWrap.querySelector(
        ".give-loading-animation"
      );

      if (loadingAnimation) {
        loadingAnimation.style.display = "none";
      }

      if (donateButton) {
        const originalLabel = donateButton.getAttribute(
          "data-before-validation-label"
        );
        if (originalLabel) {
          donateButton.value = originalLabel;
        }
        donateButton.removeAttribute("disabled");
      }

      submitWithSuccess = false;
    }

    /**
     * Show error message
     *
     * @param {HTMLElement} formElement Form element
     * @param {string} message Error message
     */
    function showErrorMessage(formElement, message) {
      // Remove existing error messages
      const existingErrors = formElement.querySelectorAll(
        ".give-kkiapay-error"
      );
      existingErrors.forEach(function (error) {
        error.remove();
      });

      // Create error message element
      const errorDiv = document.createElement("div");
      errorDiv.className = "give_errors give-kkiapay-error";
      errorDiv.innerHTML = '<p class="give_error">' + message + "</p>";

      // Insert error message before form
      formElement.parentNode.insertBefore(errorDiv, formElement);

      // Scroll to error
      errorDiv.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }

  // Initialize when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initKkiapayWidget);
  } else {
    initKkiapayWidget();
  }

  // also initialize on Give form refresh (for multi-step forms)
  // Use jQuery for legacy event if available, otherwise ignore or use native custom event if GiveWP supports it
  if (window.jQuery)
    window.jQuery(document).on("give_gateway_loaded", initKkiapayWidget);
  else document.addEventListener("give_gateway_loaded", initKkiapayWidget);
})();
