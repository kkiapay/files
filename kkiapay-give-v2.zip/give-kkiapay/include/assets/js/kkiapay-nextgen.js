(function () {
  const registerKkiapay = () => {
    if (!window.givewp || !window.givewp.gateways) {
      setTimeout(registerKkiapay, 100);
      return;
    }

    const KkiapayGatewayConfig = {
      id: "kkiapay",

      // LA CORRECTION DÉFINITIVE : GiveWP V3 exige une méthode nommée "Fields" (avec un F majuscule)
      Fields: () => null,

      async beforeCreatePayment(paymentData) {
        return new Promise((resolve, reject) => {
          const settings = window.give_kkiapay_nextgen_vars || {};

          const kkiapayOptions = {
            amount: parseInt(paymentData.amount),
            name: `${paymentData.firstName || ""} ${paymentData.lastName || ""}`.trim(),
            email: paymentData.email || "",
            key: settings.key,
            sandbox: settings.sandbox === "true",
            theme: settings.theme,
            position: settings.position,
            paymentmethod: [settings.paymentmethod || "all"],
            reason: "Donation GiveWP",
            sdk: "givewp",
          };

          if (typeof window.openKkiapayWidget === "function") {
            window.openKkiapayWidget(kkiapayOptions);

            window.addSuccessListener((response) => {
              if (response && response.transactionId) {
                resolve({
                  kkiapay_transaction_id: response.transactionId,
                });
              } else {
                reject("Réponse Kkiapay invalide.");
              }
            });

            window.addEventListener("message", (e) => {
              if (e.data === "close" || e.data === "KPAY_CLOSE") {
                reject("Paiement annulé par le donneur.");
              }
            });
          } else {
            reject("Erreur de chargement du widget Kkiapay.");
          }
        });
      },
    };

    // On passe l'objet de configuration (un seul argument exigé)
    window.givewp.gateways.register(KkiapayGatewayConfig);
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", registerKkiapay);
  } else {
    registerKkiapay();
  }
})();
