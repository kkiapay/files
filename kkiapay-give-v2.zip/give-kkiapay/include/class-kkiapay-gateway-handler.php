<?php
/**
 * KKiapay Gateway Handler
 *
 * Handles legacy GiveWP (< 3.0) gateway registration and settings.
 * On GiveWP 3.0+, registration is handled by KkiapayGiveNextGen.
 */

namespace KkiapayGive;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class KkiapayGatewayHandler {

    private $give_version;

    public function __construct() {
        $this->give_version = defined( 'GIVE_VERSION' ) ? GIVE_VERSION : '2.5.0';

        add_filter( 'give_payment_gateways', array( $this, 'register_gateway' ), 999, 1 );
        add_action( 'give_gateway_kkiapay', array( $this, 'process_payment' ) );
        add_filter( 'give_currencies', array( $this, 'add_currency' ) );

        if ( is_admin() ) {
            add_filter( 'give_get_sections_gateways', array( $this, 'register_gateway_section' ) );
            add_filter( 'give_get_settings_gateways', array( $this, 'register_gateway_settings' ) );
        }

        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'init', array( $this, 'register_webhook_endpoint' ) );
        add_action( 'template_redirect', array( $this, 'handle_webhook' ) );
    }

    public function register_gateway( $gateways ) {
        $gateways['kkiapay'] = array(
            'admin_label'    => __( 'KKiapay', 'kkiapay-give' ),
            'checkout_label' => __( 'kkiapay', 'kkiapay-give' ),
        );
        return $gateways;
    }

    public function register_gateway_section( $sections ) {
        $sections['kkiapay'] = __( 'KKiapay', 'kkiapay-give' );
        return $sections;
    }

    public function register_gateway_settings( $settings ) {
        $current_section = give_get_current_setting_section();
        if ( 'kkiapay' !== $current_section ) {
            return $settings;
        }

        $kkiapay_settings = array(
            array(
                'id'   => 'give_title_kkiapay',
                'type' => 'title',
                'name' => __( 'KKiapay Settings', 'kkiapay-give' ),
            ),
            array(
                'id'      => 'public_key_kkiapay',
                'type'    => 'text',
                'name'    => __( 'Public Key', 'kkiapay-give' ),
                'desc'    => __( 'Enter your KKiapay public key.', 'kkiapay-give' ),
                'default' => '',
            ),
            array(
                'id'      => 'private_key_kkiapay',
                'type'    => 'text',
                'name'    => __( 'Private Key', 'kkiapay-give' ),
                'desc'    => __( 'Enter your KKiapay private key.', 'kkiapay-give' ),
                'default' => '',
            ),
            array(
                'id'      => 'secret_key_kkiapay',
                'type'    => 'text',
                'name'    => __( 'Secret Key', 'kkiapay-give' ),
                'desc'    => __( 'Enter your KKiapay secret key.', 'kkiapay-give' ),
                'default' => '',
            ),
            array(
                'id'      => 'position_kkiapay',
                'type'    => 'select',
                'name'    => __( 'Widget Position', 'kkiapay-give' ),
                'options' => array(
                    'center' => __( 'Center', 'kkiapay-give' ),
                    'left'   => __( 'Left', 'kkiapay-give' ),
                    'right'  => __( 'Right', 'kkiapay-give' ),
                ),
                'default' => 'center',
            ),
            array(
                'id'      => 'theme_kkiapay',
                'type'    => 'text',
                'name'    => __( 'Widget Theme Color', 'kkiapay-give' ),
                'desc'    => __( 'Hex color (e.g. #FF6600) for the widget theme.', 'kkiapay-give' ),
                'default' => '',
            ),
            array(
                'id'      => 'payment_method_kkiapay',
                'type'    => 'select',
                'name'    => __( 'Payment Methods', 'kkiapay-give' ),
                'options' => array(
                    'all'  => __( 'All', 'kkiapay-give' ),
                    'momo' => __( 'Mobile Money only', 'kkiapay-give' ),
                    'card' => __( 'Card only', 'kkiapay-give' ),
                    'moov' => __( 'Moov Money only', 'kkiapay-give' ),
                ),
                'default' => 'all',
            ),
            array(
                'id'   => 'give_title_kkiapay',
                'type' => 'sectionend',
            ),
        );

        return array_merge( $settings, $kkiapay_settings );
    }

    public function add_currency( $currencies ) {
        $currencies['XOF'] = array(
            'admin_label' => __( 'West African CFA Franc (XOF)', 'kkiapay-give' ),
            'symbol'      => 'CFA',
            'symbol_pos'  => 'after',
        );
        return $currencies;
    }

    public function enqueue_scripts() {
        if ( ! give_is_gateway_active( 'kkiapay' ) ) {
            return;
        }
        if ( ! is_singular( 'give_forms' ) && ! give_is_checkout() ) {
            return;
        }

        wp_enqueue_script( 'kkiapay-widget', 'https://cdn.kkiapay.me/k.js', array(), KKIAPAY_GIVE_VERSION, true );
        wp_enqueue_script(
            'give-kkiapay',
            KKIAPAY_GIVE_PLUGIN_URL . 'include/assets/js/kkiapay.js',
            array( 'jquery', 'kkiapay-widget' ),
            KKIAPAY_GIVE_VERSION,
            true
        );
        wp_localize_script( 'give-kkiapay', 'give_kkiapay_vars', array(
            'key'           => give_get_option( 'public_key_kkiapay', '' ),
            'sandbox'       => give_is_test_mode() ? 'true' : 'false',
            'position'      => give_get_option( 'position_kkiapay', 'center' ),
            'theme'         => give_get_option( 'theme_kkiapay', '' ),
            'paymentmethod' => give_get_option( 'payment_method_kkiapay', 'all' ),
        ) );
    }

    public function process_payment( $purchase_data ) {
        $payment_data = array(
            'price'           => $purchase_data['price'],
            'give_form_title' => $purchase_data['post_data']['give-form-title'],
            'give_form_id'    => intval( $purchase_data['post_data']['give-form-id'] ),
            'date'            => $purchase_data['date'],
            'user_email'      => $purchase_data['user_email'],
            'purchase_key'    => $purchase_data['purchase_key'],
            'currency'        => give_get_currency(),
            'user_info'       => $purchase_data['user_info'],
            'status'          => 'pending',
            'gateway'         => 'kkiapay',
        );

        $payment_id = give_insert_payment( $payment_data );

        if ( ! $payment_id ) {
            give_send_back_to_checkout( '?payment-mode=kkiapay' );
            return;
        }

        $transaction_id = isset( $_POST['kkiapay_transaction_id'] ) ? sanitize_text_field( $_POST['kkiapay_transaction_id'] ) : '';

        if ( empty( $transaction_id ) ) {
            give_update_payment_status( $payment_id, 'failed' );
            give_send_back_to_checkout( '?payment-mode=kkiapay' );
            return;
        }

        $kkiapay  = new KkiapayGateway(
            give_get_option( 'public_key_kkiapay' ),
            give_get_option( 'private_key_kkiapay' ),
            give_get_option( 'secret_key_kkiapay' ),
            give_is_test_mode()
        );
        $response = $kkiapay->verifyTransaction( $transaction_id );

        if ( isset( $response->status ) && $response->status === 'SUCCESS' ) {
            give_set_payment_transaction_id( $payment_id, $transaction_id );
            give_update_payment_status( $payment_id, 'complete' );
            give_send_to_success_page();
        } else {
            give_update_payment_status( $payment_id, 'failed' );
            give_send_back_to_checkout( '?payment-mode=kkiapay' );
        }
    }

    public function register_webhook_endpoint() {
        add_rewrite_endpoint( 'kkiapay-webhook', EP_ROOT );
    }

    public function handle_webhook() {
        global $wp_query;
        if ( ! isset( $wp_query->query_vars['kkiapay-webhook'] ) ) {
            return;
        }

        $body = file_get_contents( 'php://input' );
        $data = json_decode( $body );

        if ( empty( $data ) || ! isset( $data->transactionId ) ) {
            status_header( 400 );
            exit( 'Invalid payload' );
        }

        $kkiapay  = new KkiapayGateway(
            give_get_option( 'public_key_kkiapay' ),
            give_get_option( 'private_key_kkiapay' ),
            give_get_option( 'secret_key_kkiapay' ),
            give_is_test_mode()
        );
        $response = $kkiapay->verifyTransaction( sanitize_text_field( $data->transactionId ) );

        if ( isset( $response->status ) && $response->status === 'SUCCESS' ) {
            status_header( 200 );
            exit( 'OK' );
        }

        status_header( 422 );
        exit( 'Verification failed' );
    }
}
