<?php
/**
 * Plugin Name: KKiapay-Give
 * Plugin URI: https://wordpress.org/plugins/kkiapay-give-plugin
 * Description: Accept donations via Mobile Money and credit cards through KKiapay payment gateway for GiveWP.
 * Author: Kkiapay Developer Team ❤️
 * Author URI: https://kkiapay.me/
 * License: GPLv2
 * Version: 2.0.1
 * Requires at least: 5.0
 * Tested up to: 6.9
 * Requires PHP: 7.4
 * GiveWP requires at least: 2.5.0
 * GiveWP tested up to: 4.14.2
 * Text Domain: kkiapay-give
 * Domain Path: /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('KKIAPAY_GIVE_VERSION', '2.0.1');
define('KKIAPAY_GIVE_MAIN_FILE', __FILE__);
define('KKIAPAY_GIVE_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('KKIAPAY_GIVE_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Main Plugin Class
 */
final class KkiapayGivePlugin {
    
    private static $instance;

    public static function get_instance() {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('init', array($this, 'init'), 0);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'plugin_action_links'));

        // CORRECTION MAJEURE ICI : 
        // Le hook GiveWP DOIT être attaché immédiatement, bien avant l'action "init" de WordPress
        add_action('givewp_register_payment_gateway', function ($paymentGatewayRegister) {
            require_once KKIAPAY_GIVE_PLUGIN_DIR . 'include/class-kkiapay-give-nextgen.php';
            $paymentGatewayRegister->registerGateway(\KkiapayGive\KkiapayGiveNextGen::class);
        });
    }

    public function load_textdomain() {
        load_plugin_textdomain('kkiapay-give', false, basename(dirname(__FILE__)) . '/languages/');
    }

    public function init() {
        if (!$this->check_dependencies()) {
            return;
        }

        // Load API Gateway Class (Shared)
        require_once KKIAPAY_GIVE_PLUGIN_DIR . 'include/class-kkiapay-gateway.php';

        // Load Legacy Handler (V2 & V3 Back-compat)
        require_once KKIAPAY_GIVE_PLUGIN_DIR . 'include/class-kkiapay-gateway-handler.php';
        new \KkiapayGive\KkiapayGatewayHandler();
        
        // (L'enregistrement NextGen a été supprimé d'ici et déplacé dans le constructeur)
    }

    private function check_dependencies() {
        if (!class_exists('Give')) {
            add_action('admin_notices', array($this, 'missing_givewp_notice'));
            return false;
        }

        if (defined('GIVE_VERSION') && version_compare(GIVE_VERSION, '2.5.0', '<')) {
            add_action('admin_notices', array($this, 'version_notice'));
            return false;
        }

        return true;
    }

    public function missing_givewp_notice() {
        ?>
        <div class="error notice">
            <p>
                <strong><?php _e('KKiapay for GiveWP', 'kkiapay-give'); ?></strong> 
                <?php _e('requires GiveWP plugin to be installed and activated.', 'kkiapay-give'); ?>
                <a href="<?php echo admin_url('plugin-install.php?s=givewp&tab=search&type=term'); ?>" class="button button-primary">
                    <?php _e('Install GiveWP', 'kkiapay-give'); ?>
                </a>
            </p>
        </div>
        <?php
    }

    public function version_notice() {
        ?>
        <div class="error notice">
            <p>
                <strong><?php _e('KKiapay for GiveWP', 'kkiapay-give'); ?></strong> 
                <?php printf(
                    __('requires GiveWP version 2.5.0 or higher. You are using version %s. Please update GiveWP.', 'kkiapay-give'),
                    defined('GIVE_VERSION') ? GIVE_VERSION : __('Unknown', 'kkiapay-give')
                ); ?>
            </p>
        </div>
        <?php
    }

    public function plugin_action_links($links) {
        $settings_url = admin_url('edit.php?post_type=give_forms&page=give-settings&tab=gateways&section=kkiapay');
        $plugin_links = array(
            '<a href="' . esc_url($settings_url) . '">' . __('Settings', 'kkiapay-give') . '</a>',
            '<a href="https://docs.kkiapay.me" target="_blank">' . __('Documentation', 'kkiapay-give') . '</a>',
            '<a href="https://support.kkiapay.me" target="_blank">' . __('Support', 'kkiapay-give') . '</a>',
        );
        
        return array_merge($plugin_links, $links);
    }
}

// Instantiate
KkiapayGivePlugin::get_instance();