## Kkiapay-Give

[![Build Status](https://travis-ci.org/kkiapay/wordpress-plugin.svg?branch=master)](https://travis-ci.org/kkiapay/wordpress-plugin)

Kkiapay-Give is a plugin developed by the company kkiapay to receive donations on your wordpress site

KKIAPAY is available in:

* Benin
* Senegal [WIP]
* [More details at ](https://kkiapay.me/features/supported-countries)

## Warning

Please specify your public API key taking into account whether Give is in Test mode or not