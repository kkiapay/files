window.addEventListener("load",function () {
    const color_input = document.querySelector("#woocommerce_kkiapay_woocommerce_plugin_theme");
    color_input.className += "jscolor"

});
