Need to update version before update on Store. 

  Files to update :   

  - kkiapay-woocommerce-plugin.php
    * line 9:  **Version: 2.3.x**
  - readme.txt
    * line 7: **Stable tag: 2.3.x**
        
